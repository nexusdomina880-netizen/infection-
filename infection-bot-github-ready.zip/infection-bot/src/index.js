require('dotenv').config();
const { Client, LocalAuth } = require('whatsapp-web.js');
const qrcode = require('qrcode-terminal');
const handleMessage = require('./handlers/messageHandler');

const client = new Client({
  authStrategy: new LocalAuth({ clientId: 'infection-bot' }),
  puppeteer: { headless: true, args: ['--no-sandbox', '--disable-setuid-sandbox'] }
});
client.on('qr', qr => qrcode.generate(qr, { small: true }));
client.on('ready', () => console.log('infection-bot online'));
client.on('message', handleMessage);
process.on('uncaughtException', err => console.error('AntiCrash:', err));
process.on('unhandledRejection', err => console.error('AntiCrash:', err));
client.initialize();
