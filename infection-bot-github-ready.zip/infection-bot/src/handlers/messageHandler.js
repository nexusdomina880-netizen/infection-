const commands = require('./commands');
module.exports = async message => {
  if (!message.body?.startsWith('!')) return;
  const parts = message.body.trim().split(/\s+/);
  const command = parts.shift().toLowerCase();
  try { await commands(command, parts, message); }
  catch (e) { console.error(e); await message.reply('Errore del bot.'); }
};
