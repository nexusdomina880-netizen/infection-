module.exports = async (command, args, message) => {
  if (command === '!ping') return message.reply('Pong!');
  if (command === '!help') return message.reply('!ping  !help  !info  !echo testo');
  if (command === '!info') return message.reply('infection-bot — WhatsApp security bot');
  if (command === '!echo') return message.reply(args.join(' ') || 'Scrivi un testo.');
};
