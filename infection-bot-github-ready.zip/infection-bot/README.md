# infection-bot

Starter WhatsApp bot with a modular structure.

## Run
npm install
npm start

Scan the QR shown in the terminal with WhatsApp.

## Commands
!ping
!help
!info
!echo testo

Security modules can be added under `src/security/`.
